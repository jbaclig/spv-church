$(function() {
  $('body').css('opacity',1);
});
